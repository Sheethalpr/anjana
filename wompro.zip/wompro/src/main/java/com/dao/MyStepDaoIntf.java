package com.dao;

import java.util.List;

import com.model.Step;

public interface MyStepDaoIntf {


public boolean insertStepForm(Step step);
	public List<Step> getUserstep();
}
